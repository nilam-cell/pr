<?php
include 'db.php';

$id = $_POST['id'];
$name = $_POST['name'];
$dept = $_POST['department'];
$salary = $_POST['salary'];

$conn->query("INSERT INTO emp (id,name,department,salary)
              VALUES('$id','$name','$dept','$salary')");
?>