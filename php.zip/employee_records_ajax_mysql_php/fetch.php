<?php
include 'db.php';

$result = $conn->query("SELECT * FROM emp");

echo "<table border='1'>
<tr>
<th>ID</th>
<th>Name</th>
<th>Department</th>
<th>Salary</th>
<th>Action</th>
</tr>";

while($row = $result->fetch_assoc()){
    echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['name']}</td>
        <td>{$row['department']}</td>
        <td>{$row['salary']}</td>
        <td>
            <button class='delete' data-id='{$row['id']}'>Delete</button>
        </td>
    </tr>";
}

echo "</table>";
?>