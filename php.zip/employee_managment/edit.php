<?php include 'db.php'; ?>

<?php
$id = $_GET['id'];
$data = $conn->query("SELECT * FROM employees WHERE id=$id")->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Salary</title>

    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container mt-5">

<h2 class="mb-4">Update Salary</h2>

<form method="POST" class="card p-4 shadow">

    <div class="mb-3">
        <label class="form-label">Name</label>
        <p class="form-control-plaintext fw-bold">
            <?php echo $data['name']; ?>
        </p>
    </div>

    <div class="mb-3">
        <label class="form-label">Salary</label>
        <input type="text" name="salary" 
               value="<?php echo $data['salary']; ?>" 
               class="form-control">
    </div>

    <button name="update" class="btn btn-warning">Update</button>
    <a href="index.php" class="btn btn-secondary">Back</a>

</form>

</body>
</html>

<?php
if(isset($_POST['update'])){
    $salary = $_POST['salary'];

    $conn->query("UPDATE employees SET salary='$salary' WHERE id=$id");
    header("Location: index.php");
}
?>