<?php
include 'db.php';
$id = $_POST['book_id'];
$name = $_POST['book_name'];
$author = $_POST['author'];
$price = $_POST['price'];

$conn->query("INSERT INTO books(book_id,book_name,author,price) 
              VALUES('$id','$name','$author','$price')");
?>