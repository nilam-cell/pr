<?php
include 'db.php';

$result = $conn->query("SELECT * FROM books");

echo "<table class='table table-bordered table-striped table-hover'>
<tr class='table-dark'>
<th>ID</th>
<th>Name</th>
<th>Author</th>
<th>Price</th>
<th>Action</th>
</tr>";

while($row = $result->fetch_assoc()){
    echo "<tr>
        <td>{$row['book_id']}</td>
        <td>{$row['book_name']}</td>
        <td>{$row['author']}</td>
        <td>{$row['price']}</td>
        <td>
            <button class='btn btn-danger btn-sm delete' data-id='{$row['book_id']}'>Delete</button>
        </td>
    </tr>";
}

echo "</table>";
?>