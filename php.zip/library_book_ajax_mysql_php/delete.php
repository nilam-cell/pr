<?php
include 'db.php';

$id = $_POST['id'];
$conn->query("DELETE FROM books WHERE book_id=$id");
?>