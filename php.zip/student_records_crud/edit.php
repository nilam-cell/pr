<?php include 'db.php'; ?>

<?php
$id = $_GET['id'];
$data = $conn->query("SELECT * FROM students WHERE id=$id")->fetch_assoc();
?>

<h2>Edit Student</h2>
<form method="POST">
    Name: <input type="text" name="name" value="<?php echo $data['name']; ?>"><br>
    Email: <input type="text" name="email" value="<?php echo $data['email']; ?>"><br>
    <button name="update">Update</button>
</form>

<?php
if(isset($_POST['update'])){
    $name = $_POST['name'];
    $email = $_POST['email'];

    $conn->query("UPDATE students SET name='$name', email='$email' WHERE id=$id");
    header("Location: index.php");
}
?>